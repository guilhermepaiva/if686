
public class BlocoGuardadoTest {

	public static BlocoGuardado blocoGuardado;

	public static void main(String[] args) {

		blocoGuardado = new BlocoGuardado();

		blocoGuardado.guarda();
		
	}
}